package rushdef;

import battlecode.common.GameActionException;
import battlecode.common.RobotController;

public class Unit extends Robot {

    public Unit(RobotController r) {
        super(r);
    }

    public void initialize() throws GameActionException {
        super.initialize();
    }
}