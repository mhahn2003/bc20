package rushdef;

import battlecode.common.GameActionException;
import battlecode.common.RobotController;

public class Building extends Robot {

    public Building(RobotController r) {
        super(r);
        // building specific setup here
    }

    public void takeTurn() throws GameActionException {
        super.takeTurn();
    }
}