package teraform;
import battlecode.common.*;

public class Unit extends Robot {

    MapLocation hqLoc;

    public Unit(RobotController r) {
        super(r);
    }

    public void initialize() throws GameActionException {
        super.initialize();
    }
}